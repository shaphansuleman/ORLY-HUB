import React from 'react';
function App() {
  return <div className='text-yellow-500 bg-black text-center p-4'>Welcome to ORLY HUB</div>;
}
export default App;